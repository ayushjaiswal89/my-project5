from flask import Flask,render_template
from flask_sqlalchemy import SQLAlchemy

app=Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:@localhost/grandcoffee'
db=SQLAlchemy(app)

class gallery(db.Model):
    sno = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    img = db.Column(db.String(12), nullable=False)



@app.route("/")
def index():
    return render_template("index.html")

@app.route("/about")
def about():
    return render_template("about.html")


@app.route("/contact")
def contact():
    return render_template("contact.html")


@app.route("/gallery")
def galleryone():

    data=gallery.query.filter_by().all()
    return render_template("gallery.html",mydata=data)


@app.route("/services")
def services():
    return render_template("services.html")

app.run(debug="True")
